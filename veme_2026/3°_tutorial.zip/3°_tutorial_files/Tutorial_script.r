install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


# 1. Extracting spatio-temporal information embedded in trees

localTreesDirectory = "Extracted_trees"
dir.create(localTreesDirectory, showWarnings=F)
trees = readAnnotatedNexus("RABV_100.trees")
mostRecentSamplingDatum = 2004.7
for (i in 1:length(trees))
	{
		tab = postTreeExtractions(post_tre=trees[[i]], mostRecentSamplingDatum)
		write.csv(tab, paste0(localTreesDirectory,"/TreeExtractions_",i,".csv"), row.names=F, quote=F)
	}


# 2. Preliminary analysis of the environmental raster

rast = raster("Elevation_rast.asc")
names(rast) = "elevation"
rast[rast[]<0] = 0
rast[] = rast[] + 1

nberOfExtractionFiles = 100
envVariables = list(rast)
pathModel = 2
resistances = c(TRUE)
avgResistances = c(TRUE)
fourCells = FALSE
nberOfRandomisations = 0
randomProcedure = 3
outputName = "RABV_elevation_least-cost"

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
			  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)

tab = read.table("RABV_elevation_least-cost_linear_regression_results.txt", header=T)
LR_coefficients = tab[,"LR2_coefficients_elevation_R"]
	print(sum(LR_coefficients > 0))
Qs = tab[,"LR2_Q_elevation_R"]
	print(sum(Qs > 0))
	print(mean(Qs))


# 3. Assessing statistical support with a randomisation procedure

nberOfRandomisations = 1

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
			  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)

