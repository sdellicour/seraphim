install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems


# 1. Extracting the spatio-temporal information contained in trees:

localTreesDirectory = "Extracted_trees"
allTrees = scan(file="RABV_gamma.trees", what="", sep="\n", quiet=TRUE)
burnIn = 1001
randomSampling = FALSE
nberOfTreesToSample = 100
mostRecentSamplingDatum = 2004.7
coordinateAttributeName = "location"

treeExtractions(localTreesDirectory, allTrees, burnIn, randomSampling,
				nberOfTreesToSample, mostRecentSamplingDatum, coordinateAttributeName)


# 2. Estimating dispersal/epidemiological statistics (optional)

nberOfExtractionFiles = 100
timeSlices = 100
onlyTipBranches = FALSE
showingPlots = FALSE
outputName = "RABV_raccoon"

spreadStatistics(localTreesDirectory, nberOfExtractionFiles, timeSlices, 
				 onlyTipBranches, showingPlots, outputName)


# 3. Preliminary analysis of the correlation between dispersal times and environmental distances:

rast = raster("Elevation_raster.asc")
rast[rast[]<0] = 0
rast[] = rast[] + 1
plotRaster(rast, addAxes=T, addLegend=T)

nberOfExtractionFiles = 100
envVariables = list(rast)
pathModel = 2
resistances = c(TRUE)
avgResistances = c(TRUE)
fourCells = FALSE
nberOfRandomisations = 0
randomProcedure = 3
outputName = "RABV_least-cost"

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
			  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)


# 4. Testing the correlation with a randomisation procedure:

nberOfRandomisations = 1

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
			  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)

