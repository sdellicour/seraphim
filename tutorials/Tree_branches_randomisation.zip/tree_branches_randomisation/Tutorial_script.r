install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


localTreesDirectory = "Extracted_trees"
nberOfExtractionFiles = 100
envVariable = raster("Elevation_rast.tif")
envVariable[(envVariable[]<0)] = 0
overwrite = TRUE; showingPlots = TRUE


# 1. Tree randomisations without the environmental factor influencing the dispersal location of lineages

resistance = NULL

	# 1.1. Randomisations of nodes position while maintaining the branches length, the tree topology and the location of the most ancestral node

randomisationDirectory = "Randomisations/Randomisations_1.1"; randomProcedure = 3
treesRandomisation(localTreesDirectory, randomisationDirectory, nberOfExtractionFiles, envVariable, randomProcedure, resistance, overwrite, showingPlots)

	# 1.2. Randomisations of nodes position while maintaining the branches length and the location of the starting node of each branch

randomisationDirectory = "Randomisations/Randomisations_1.2"; randomProcedure = 4
treesRandomisation(localTreesDirectory, randomisationDirectory, nberOfExtractionFiles, envVariable, randomProcedure, resistance, overwrite, showingPlots)


# 2. Tree randomisations while simulating a negative impact of the environmental variable tending to 'repulse' lineages

resistance = NULL

	# 2.1. Randomisations of nodes position while maintaining the branches length, the tree topology and the location of the most ancestral node

randomisationDirectory = "Randomisations/Randomisations_2.1"; randomProcedure = 3
treesRandomisation(localTreesDirectory, randomisationDirectory, nberOfExtractionFiles, envVariable, randomProcedure, resistance, overwrite, showingPlots)

	# 2.2. Randomisations of nodes position while maintaining the branches length and the location of the starting node of each branch

randomisationDirectory = "Randomisations/Randomisations_2.2"; randomProcedure = 4
treesRandomisation(localTreesDirectory, randomisationDirectory, nberOfExtractionFiles, envVariable, randomProcedure, resistance, overwrite, showingPlots)


# 3. Tree randomisations while simulating a negative impact of the environmental variable tending to 'attract' lineages

resistance = NULL

	# 3.1. Randomisations of nodes position while maintaining the branches length, the tree topology and the location of the most ancestral node

randomisationDirectory = "Randomisations/Randomisations_3.1"; randomProcedure = 3
treesRandomisation(localTreesDirectory, randomisationDirectory, nberOfExtractionFiles, envVariable, randomProcedure, resistance, overwrite, showingPlots)

	# 3.2. Randomisations of nodes position while maintaining the branches length and the location of the starting node of each branch

randomisationDirectory = "Randomisations/Randomisations_3.2"; randomProcedure = 4
treesRandomisation(localTreesDirectory, randomisationDirectory, nberOfExtractionFiles, envVariable, randomProcedure, resistance, overwrite, showingPlots)

