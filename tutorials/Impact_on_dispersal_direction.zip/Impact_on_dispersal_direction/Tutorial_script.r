install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


localTreesDirectory = "Extracted_trees"
nberOfExtractionFiles = 900
envVariables = list(raster("Pop_density.asc"))
pathModel = 0
resistances = c(FALSE)
avgResistances = c(FALSE)
fourCells = FALSE
nberOfRandomisations = 1
randomProcedure = 3
outputName = "Pop_density"
showingPlots = FALSE

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances, avgResistances, 
			  fourCells, nberOfRandomisations, randomProcedure, outputName, showingPlots)

print(read.table("Pop_density_direction1_Bayes_factors.txt", header=T))
print(read.table("Pop_density_direction2_Bayes_factors.txt", header=T))
