BEAGLEPATH="/usr/local/lib/"
java -Djava.library.path="$BEAGLEPATH" -jar beast_1_10_5_30-12-2024.jar RABV_original_coordinates.xml
java -Djava.library.path="$BEAGLEPATH" -jar beast_1_10_5_30-12-2024.jar RABV_MDS_nullRaster_LC_R.xml
java -Djava.library.path="$BEAGLEPATH" -jar beast_1_10_5_30-12-2024.jar RABV_MDS_elevation_LC_R.xml
java -Djava.library.path="$BEAGLEPATH" -jar beast_1_10_5_30-12-2024.jar RABV_cartogram_Elevation_R.xml
