install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


# 1. Installing additional packages

install.packages("cartogram")
library(cartogram)
install.packages("sf")
library(sf)


# 2. Rescaling the environmental raster

rast = raster("Elevation_raster.asc")
k = 10; M = max(rast[], na.rm=T)
rast[!is.na(rast[])] = (rast[!is.na(rast[])]*(k/M))
rast[!is.na(rast[])] = rast[!is.na(rast[])] + 1


# 3. First cartogram transformation test

envVariable = rasterToPolygons(rast)
names(envVariable) = "envVariable"
envVariable = st_transform(st_as_sf(envVariable), 3857)
cartogram = cartogram_cont(envVariable, "envVariable", itermax=5)
plot(cartogram)


# 4. Performing MDS and cartogram transformations

input = read.dna("Raccoon_rabies.fasta", format="fasta")
# input = read.table("Raccoon_rabies.txt", header=F)
envVariables = list(rast)
resistances = c(TRUE)
avgResistances = c(TRUE)
fourCells = FALSE
pathModel = 2
outputName = "RABV"
OS = "Unix"

mdsTransformation(input, envVariables, pathModel, resistances, avgResistances, fourCells, outputName, OS)
cartogramTransformation(input, envVariables, resistances, outputName)


# 5. Running a continuous phylogeographic analysis using BEAST and based on each generated fasta file

	# - select a RRW diffusion model (Cauchy, gamma, or lognormal)
	# - add the estimation of the "location.squareddistTime4.Rsquared" statistic in the xml file
		# (and ask to log it; see the examples associated with this tutorial)


# 6. Estimating Bayes factor supports by comparing the log files

R2_mdsNullRaster = read.table("Raccoon_rabies_res/RABV_MDS_nullRaster_LC_R.log", header=T)[62:601,"location.squareddistTime4.Rsquared"]
R2_mdsEnvRaster = read.table("Raccoon_rabies_res/RABV_MDS_elevation_LC_R.log", header=T)[62:601,"location.squareddistTime4.Rsquared"]
Q = R2_mdsEnvRaster - R2_mdsNullRaster
p = (sum(Q>0))/length(Q)
BF_MDS = p/(1-p); BF_MDS

R2_originalCoordinates = read.table("Raccoon_rabies_res/RABV_original_coordinates.log", header=T)[62:601,"location.squareddistTime4.Rsquared"]
R2_cartogram = read.table("Raccoon_rabies_res/RABV_cartogram_elevation_R.log", header=T)[62:601,"location.squareddistTime4.Rsquared"]
Q = R2_cartogram  - R2_originalCoordinates
p = (sum(Q>0))/length(Q)
BF_cartogram = p/(1-p); BF_cartogram

