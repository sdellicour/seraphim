install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


# 1. Extracting spatio-temporal information embedded in trees

localTreesDirectory = "Extracted_trees"
nberOfTreesToSample = 100
mostRecentSamplingDatum = 2004.7

	# 1.1. First option: with the "treeExtractions" function

allTrees = scan(file="RABV_gamma.trees", what="", sep="\n", quiet=T)
burnIn = 1001
randomSampling = FALSE
coordinateAttributeName = "location"

treeExtractions(localTreesDirectory, allTrees, burnIn, randomSampling, 
				nberOfTreesToSample, mostRecentSamplingDatum, coordinateAttributeName)

	# 1.2. Second option: with the "postTreeExtractions" function (advised)

trees = readAnnotatedNexus("RABV_gamma.trees")
dir.create(localTreesDirectory, showWarnings=F)
trees_to_extract = trees[seq(1101,11001,100)]
for (i in 1:length(trees_to_extract))
	{
		tab = postTreeExtractions(post_tre=trees_to_extract[[i]], mostRecentSamplingDatum)
		write.csv(tab, paste0(localTreesDirectory,"/TreeExtractions_",i,".csv"), row.names=F, quote=F)
	}


# 2. Preliminary analysis of the environmental raster

rast = raster("Elevation_raster.asc")
names(rast) = "elevation"
rast[rast[]<0] = 0
rast[] = rast[] + 1
plotRaster(rast, addAxes=T, addLegend=T)

nberOfExtractionFiles = 100
envVariables = list(rast)
pathModel = 2
resistances = c(TRUE)
avgResistances = c(TRUE)
fourCells = FALSE
nberOfRandomisations = 0
randomProcedure = 3
outputName = "RABV_elevation_least-cost"

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
			  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)

tab = read.table("RABV_elevation_least-cost_linear_regression_results.txt", header=T)
LR_coefficients = tab[,"LR2_coefficients_elevation_R"]
	print(sum(LR_coefficients > 0))
Qs = tab[,"LR2_Q_elevation_R"]
	print(sum(Qs > 0))
	print(mean(Qs))


# 3. Assessing statistical support with a randomisation procedure

nberOfRandomisations = 1

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
			  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)


# Alternative analysis: investigation of the isolation-by-resistance patterns

nberOfRandomisations = 1

isolationByResistance(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances,
					  avgResistances, fourCells, nberOfRandomisations, randomProcedure, outputName)

tab = read.table("RABV_elevation_least-cost_linear_regression_results.txt", header=T)
LR_coefficients = tab[,"LR_coefficients_elevation_R"]
	print(sum(LR_coefficients > 0))
Qs = tab[,"LR_Q_elevation_R"]
	print(sum(Qs > 0))
	print(mean(Qs))

