install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


# 1. Extracting spatio-temporal information embedded in trees

localTreesDirectory = "Extracted_trees"
nberOfTreesToSample = 100
mostRecentSamplingDatum = 2004.7

	# 1.1. First option: with the "treeExtractions" function

allTrees = scan(file="RABV_gamma.trees", what="", sep="\n", quiet=T)
burnIn = 1001
randomSampling = FALSE
coordinateAttributeName = "location"

treeExtractions(localTreesDirectory, allTrees, burnIn, randomSampling, 
				nberOfTreesToSample, mostRecentSamplingDatum, coordinateAttributeName)

	# 1.2. Second option: with the "postTreeExtractions" function (advised)

trees = readAnnotatedNexus("RABV_gamma.trees")
dir.create(localTreesDirectory, showWarnings=F)
trees_to_extract = trees[seq(1101,11001,100)]
for (i in 1:length(trees_to_extract))
	{
		tab = postTreeExtractions(post_tre=trees_to_extract[[i]], mostRecentSamplingDatum)
		write.csv(tab, paste0(localTreesDirectory,"/TreeExtractions_",i,".csv"), row.names=F, quote=F)
	}


# 2. Investigating the association between an environmental raster and the dispersal location of viral lineages

localTreesDirectory = "Extracted_trees"
nberOfExtractionFiles = 100
envVariables = list(raster("Elevation_rast.tif"))
pathModel = 0
resistances = c(TRUE)
avgResistances = c(TRUE)
fourCells = FALSE
nberOfRandomisations = 1
randomProcedure = 3
outputName = "Elevation"
showingPlots = FALSE

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances, avgResistances, 
			  fourCells, nberOfRandomisations, randomProcedure, outputName, showingPlots)

print(read.table("Elevation_position_E_BF_results.txt", header=T))
print(read.table("Elevation_direction_R_BF_results.txt", header=T))

dev.new(width=5.0, height=2.0); par(mgp=c(0,0,0), oma=c(0,0,0,0.3), mar=c(2.5,2.7,0.4,0), lwd=0.4, col="gray30")
E_obs = read.csv("Elevation_mean_evironmental_values_at_node_locations.csv", head=T)
E_ran = read.csv("Elevation_mean_evironmental_values_at_node_locations_randomisation_1.csv", head=T)
E_delta = E_obs[,"Elevation_rast_R"]-E_ran[,"Elevation_rast_R"]
col1 = rgb(222,67,39,220,maxColorValue=255); col2 = rgb(222,67,39,100,maxColorValue=255)
plot(density(E_delta), ann=F, axes=F, frame.plot=T, cex=0.4, pch=16, col=NA, xlim=c(-450,450))
polygon(density(E_delta), col=col2, border=NA); lines(density(E_delta), col=col1, lwd=0.8); ats = c(0,0.002,0.004)
axis(side=1, lwd.tick=0.4, cex.axis=0.7, mgp=c(0,0.15,0), lwd=0, tck=-0.04, col.tick="gray30", col.axis="gray30", col="gray30")
axis(side=2, lwd.tick=0.4, cex.axis=0.7, mgp=c(0,0.35,0), lwd=0, tck=-0.04, col.tick="gray30", col.axis="gray30", col="gray30", at=ats, labels=ats)
title(ylab="Density", cex.lab=0.85, col.lab="gray30", mgp=c(1.5,0,0)); abline(v=0, lty=2, col="gray50", lwd=1)
title(xlab=expression(italic("E")*" differences"), cex.lab=0.85, col.lab="gray30", mgp=c(1.2,0,0))


