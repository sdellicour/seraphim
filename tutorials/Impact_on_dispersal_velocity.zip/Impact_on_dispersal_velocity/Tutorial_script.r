install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems


# 1. Extracting spatio-temporal information in trees:

localTreesDirectory = "Extracted_trees"
allTrees = scan(file="RABV_gamma.trees", what="", sep="\n", quiet=TRUE)
burnIn = 1000
randomSampling = FALSE
nberOfTreesToSample = 100
mostRecentSamplingDatum = 2004.7
coordinateAttributeName = "location"

treeExtractions(localTreesDirectory, allTrees, burnIn, randomSampling, nberOfTreesToSample, mostRecentSamplingDatum, coordinateAttributeName)


# 2. Estimating the correlation between branch durations and environmental distances:

nberOfExtractionFiles = 100
envVariables = list(raster("Elevation_raster.asc"))
envVariables[[1]][] = envVariables[[1]][] + 1
pathModel = 2
resistances = c(TRUE)
avgResistances = c(TRUE)
fourCells = FALSE
nberOfRandomisations = 0
randomProcedure = 3
outputName = "Elevation_least-cost"
showingPlots = FALSE
nberOfCores = 1
OS = "Unix"

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances, avgResistances, 
			  fourCells, nberOfRandomisations, randomProcedure, outputName, showingPlots, nberOfCores, OS)

tab = read.table("Elevation_least-cost_LR_results.txt", header=T)
LR_coefficients = tab[,"Univariate_LR_coefficients_Elevation_raster_R"]
	print(sum(LR_coefficients > 0))
Qs = tab[,"Univariate_LR_delta_R2_Elevation_raster_R"]
	print(sum(Qs > 0))


# 3. Testing the significance with a randomisation procedure:

	# 3.1. First approach: reporting a proportion of p-values < 0.05

envVariables = list(raster("Elevation_raster.asc"))
envVariables[[1]][] = envVariables[[1]][] + 1
nberOfRandomisations = 100
outputName = "Elevation_least-cost"

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances, avgResistances, 
			  fourCells, nberOfRandomisations, randomProcedure, outputName, showingPlots, nberOfCores, OS)

tab = read.table("Elevation_least-cost_randomisation_results.txt", header=T)
a = tab[,"Uni_LR_delta_R2_p.values_Elevation_R"]
print(length(a[a[]<0.05]))

	# 3.2. Second approach: reporting a Bayes factor

envVariables = list(raster("Elevation_raster.asc"))
envVariables[[1]][] = envVariables[[1]][] + 1
nberOfRandomisations = 1
outputName = "Elevation_least-cost"

spreadFactors(localTreesDirectory, nberOfExtractionFiles, envVariables, pathModel, resistances, avgResistances, 
			  fourCells, nberOfRandomisations, randomProcedure, outputName, showingPlots, nberOfCores, OS)
	
					      