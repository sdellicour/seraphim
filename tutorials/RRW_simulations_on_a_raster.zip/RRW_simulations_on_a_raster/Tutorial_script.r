install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


# 1. Preparation of the environmental raster:

envVariable = raster("Elevation_rast.asc")
envVariable[(envVariable[]<0)] = 0
envVariable[] = (envVariable[]/max(envVariable[],na.rm=T))*10


# 2. Simulation of a RRW diffusion process on the rescaled raster

resistance = TRUE
scalingValue = 2
ancestPosition = c(-78.60,39.02)
birthRate = 0.2
samplingRate = 0.2
startingYear = 1972
samplingWindow = cbind(1982.2,2004.7)
timeSlice = 1/12
timeIntervale = 1/12
showingPlots = FALSE
extractionOfValuesOnMatrix = FALSE

simulation = simulatorRRW3(envVariable, resistance, scalingValue, ancestPosition, birthRate, samplingRate, startingYear, 
						   samplingWindow, timeSlice, timeIntervale, showingPlots, extractionOfValuesOnMatrix)

write.csv(simulation[[1]], "RRW_simulation.csv", quote=F, row.names=F)
write.tree(simulation[[2]], "RRW_simulation.tree")

