install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


# 1. Extracting spatio-temporal information from a tree
 
allTrees = scan("EBOV_cauchy.tree", what="", sep="\n", quiet=TRUE)
localTreesDirectory = "."
burnIn = 0
randomSampling = FALSE
nberOfTreesToSample = 1
mostRecentSamplingDatum = 2015.696
coordinateAttributeName = "coordinates"

treeExtractions(localTreesDirectory, allTrees, burnIn, randomSampling, nberOfTreesToSample,
				mostRecentSamplingDatum, coordinateAttributeName)


# 2. Simulations of a RRW diffusion process along the tree

tree = readAnnotatedNexus("EBOV_cauchy.tree")
rates = c()
for (i in 1:length(tree$annotations)) rates = c(rates, tree$annotations[[i]]$rate)
tab = read.csv("TreeExtractions_1.csv",sep=",")
log = read.table("EBOV_cauchy.log", header=T)
col11 = log[1,"treeLengthPrecision1"]
col12 = log[1,"treeLengthPrecision3"]
col22 = log[1,"treeLengthPrecision2"]
my_prec = c(col11, col12, col12, col22)
my_var = solve(matrix(my_prec,nrow=2))			
sigma1 = sqrt(my_var[1,1])
sigma2 = sqrt(my_var[2,2])
sigmas = c(sigma1, sigma2)
cor = my_var[1,2]/(sqrt(my_var[1,1])*sqrt(my_var[2,2]))
envVariables = list(raster("Empty_raster.asc"))
ancestID = which(!tab[,"node1"]%in%tab[,"node2"])[1]
ancestPosition = c(tab[ancestID,"startLon"], tab[ancestID,"startLat"])
reciprocalRates = FALSE
n1 = 100; n2 = 0
showingPlots = TRUE
newPlot = TRUE

sim = simulatorRRW1(tree, rates, sigmas, cor, envVariables, mostRecentSamplingDatum,
					ancestPosition, reciprocalRates, n1, n2, showingPlots, newPlot)

write.csv(sim, "TreeSimulation_1.txt", row.names=F, quote=F)


# 3. Plotting some graphical representations

rast = envVariables[[1]]
plot(rast, col="gray90", bty="n", box=F, axes=F, useRaster=T, interpolate=T, legend=F, axis.args=list(cex.axis=0.7))
rect(xmin(rast), ymin(rast), xmax(rast), ymax(rast), xpd=T, lwd=0.25)
axis(1, c(ceiling(xmin(rast)), floor(xmax(rast))), pos=ymin(rast), cex.axis=0.7, lwd=0, lwd.tick=0.25, padj=-0.8)
axis(2, c(ceiling(ymin(rast)), floor(ymax(rast))), pos=xmin(rast), cex.axis=0.7, lwd=0, lwd.tick=0.25, padj=1)			
for (i in 1:dim(tab)[1]) segments(tab[i,"startLon"], tab[i,"startLat"], tab[i,"endLon"], tab[i,"endLat"], col="black", lwd=0.25)
for (i in 1:dim(sim)[1]) segments(sim[i,"startLon"], sim[i,"startLat"], sim[i,"endLon"], sim[i,"endLat"], col="green3", lwd=0.25)

