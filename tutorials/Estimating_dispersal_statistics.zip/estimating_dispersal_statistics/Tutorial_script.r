install.packages("devtools"); library(devtools)
install_github("sdellicour/seraphim/unix_OS") # for Unix systems
install_github("sdellicour/seraphim/windows") # for Windows systems

library(seraphim)


# 1. Extracting spatio-temporal information embedded in trees

localTreesDirectory = "Extracted_trees"
nberOfTreesToSample = 100
mostRecentSamplingDatum = 2007.63

	# 1.1. First option: with the "treeExtractions" function

allTrees = scan(file="WNV_gamma.trees", what="", sep="\n", quiet=T)
burnIn = 0
randomSampling = FALSE
coordinateAttributeName = "location"

treeExtractions(localTreesDirectory, allTrees, burnIn, randomSampling, 
				nberOfTreesToSample, mostRecentSamplingDatum, coordinateAttributeName)

	# 1.2. Second option: with the "postTreeExtractions" function (advised)

trees = readAnnotatedNexus("WNV_gamma.trees")
dir.create(localTreesDirectory, showWarnings=F)
for (i in 1:length(trees))
	{
		tab = postTreeExtractions(post_tre=trees[[i]], mostRecentSamplingDatum)
		write.csv(tab, paste0(localTreesDirectory,"/TreeExtractions_",i,".csv"), row.names=F, quote=F)
	}

# 2. Estimation of several dispersal statistics

nberOfExtractionFiles = 100
timeSlices = 100
onlyTipBranches = FALSE
showingPlots = FALSE
outputName = "WNV"
nberOfCores = 1
slidingWindow = 1

spreadStatistics(localTreesDirectory, nberOfExtractionFiles, timeSlices, onlyTipBranches, 
				 showingPlots, outputName, nberOfCores, slidingWindow)

