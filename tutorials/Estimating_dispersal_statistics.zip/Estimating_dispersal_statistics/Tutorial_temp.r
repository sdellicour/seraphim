meanStatistics = read.table("WNV_estimated_statistics.txt", header=T)
waveFrontDistances1MedianValue = read.table("WNV_median_spatial_wavefront_distance.txt", header=T)[,"distance"]
lower_l_1 = read.table("WNV_95%HPD_spatial_wavefront_distance.txt", header=T)[,2]
upper_l_1 = read.table("WNV_95%HPD_spatial_wavefront_distance.txt", header=T)[,3]
dispersalVelocitiesMedianValue = read.table("WNV_mean_weighted_branch_dispersal_velocity.txt", header=T)[,"velocity"]
lower_l = read.table("WNV_95%HPD_weighted_branch_dispersal_velocity.txt", header=T)[,2]
upper_l = read.table("WNV_95%HPD_weighted_branch_dispersal_velocity.txt", header=T)[,3]
xLim = c(1997.264, 2007.630); yLim1 = c(0, 4410.616); yLim = c(0, 1382.69)

pdf("WNV_stats.pdf", width=6, height=7.5); # dev.new(width=6, height=7.5)
LWD = 0.2; LINE = 0.7; par(mfrow=c(3,2), mgp=c(10,0.35,0), oma=c(1,0.5,1,3), mar=c(3,4,2,0), lwd=0.2, col="gray30")
	H = Hpi(cbind(meanStatistics[,1], meanStatistics[,3]))
kde = kde(cbind(meanStatistics[,1], meanStatistics[,3]), H=H)
text = "Kernel density estimates of mean branch dispersal velocity parameters"
colours = c("#FFFFFF","#D2D3D3","#9D9FA3","#6A6A6D")
xLab = "mean branch dispersal velocity"; yLab = "mean branch velocity variation among lineages"
plot(kde, display="filled.contour2", cont=c(50,75,95), col=colours, axes=F, ann=F, xlim=c(0,10000))
axis(side=1, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.020, col.axis="gray30", mgp=c(0,0.2,0))
axis(side=2, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.015, col.axis="gray30")
title(xlab=xLab, cex.lab=0.7, mgp=c(1.4,0,0), col.lab="gray30")
title(ylab=yLab, cex.lab=0.7, mgp=c(1.5,0,0), col.lab="gray30")
title(main=text, cex.main=0.6, col.main="gray30", line=LINE)
legend("bottomright", c("","95% HPD","75% HPD","50% HPD"), text.col="gray30", pch=15, pt.cex=1.5, col=colours, box.lty=0, cex=0.6, y.intersp=1.2)
box(lwd=LWD, col="gray30")
	H = Hpi(cbind(meanStatistics[,2], meanStatistics[,3]))
kde = kde(cbind(meanStatistics[,2], meanStatistics[,3]), H=H)
text = "Kernel density estimates of weighted branch dispersal velocity parameters"
colours = c("#FFFFFF","#D2D3D3","#9D9FA3","#6A6A6D")
xLab = "weighted branch dispersal velocity"; yLab="weighted branch dispersal velocity variation among lineages"
plot(kde, display="filled.contour2", cont=c(50,75,95), col=colours, axes=F, ann=F)
axis(side=1, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.020, col.axis="gray30", mgp=c(0,0.2,0))
axis(side=2, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.015, col.axis="gray30")
title(xlab=xLab, cex.lab=0.7, mgp=c(1.4,0,0), col.lab="gray30")
title(ylab=yLab, cex.lab=0.7, mgp=c(1.5,0,0), col.lab="gray30")
title(main=text, cex.main=0.6, col.main="gray30", line=LINE)
legend("bottomright", c("","95% HPD","75% HPD","50% HPD"), text.col="gray30", pch=15, pt.cex=1.5, col=colours, box.lty=0, cex=0.6, y.intersp=1.2)
box(lwd=LWD, col="gray30")
	H = Hpi(cbind(meanStatistics[,4], meanStatistics[,6]))
kde = kde(cbind(meanStatistics[,4], meanStatistics[,6]), H=H)
text1 = "Kernel density estimates of original diffusion coefficient parameters"; text2 = "(Pybus et al. 2012)"
colours = c("#FFFFFF","#D2D3D3","#9D9FA3","#6A6A6D")
xLab = "mean original diffusion coefficient"; yLab="diffusion coefficient variation among lineages"
plot(kde, display="filled.contour2", cont=c(50,75,95), col=colours, axes=F, ann=F, xlim=c(0,3000000))
axis(side=1, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.020, col.axis="gray30", mgp=c(0,0.2,0))
axis(side=2, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.015, col.axis="gray30")
title(xlab=xLab, cex.lab=0.7, mgp=c(1.4,0,0), col.lab="gray30")
title(ylab=yLab, cex.lab=0.7, mgp=c(1.5,0,0), col.lab="gray30")
title(main=text1, cex.main=0.6, col.main="gray30", line=LINE)
legend("bottomright", c("","95% HPD","75% HPD","50% HPD"), text.col="gray30", pch=15, pt.cex=1.5, col=colours, box.lty=0, cex=0.6, y.intersp=1.2)
box(lwd=LWD, col="gray30")
	H = Hpi(cbind(meanStatistics[,5],meanStatistics[,6]))
kde = kde(cbind(meanStatistics[,5],meanStatistics[,6]),H=H)
text1 = "Kernel density estimates of weighted diffusion coefficient parameters"; text2 = "(Trovao et al. 2015)"
colours = c("#FFFFFF","#D2D3D3","#9D9FA3","#6A6A6D")
xLab = "mean weighted diffusion coefficient"; yLab="diffusion coefficient variation among lineages"
plot(kde, display="filled.contour2", cont=c(50,75,95), col=colours, axes=F, ann=F)
axis(side=1, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.020, col.axis="gray30", mgp=c(0,0.2,0))
axis(side=2, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.015, col.axis="gray30")
title(xlab=xLab, cex.lab=0.7, mgp=c(1.4,0,0), col.lab="gray30")
title(ylab=yLab, cex.lab=0.7, mgp=c(1.5,0,0), col.lab="gray30")
title(main=text1, cex.main=0.6, col.main="gray30", line=LINE)
legend("bottomright", c("","95% HPD","75% HPD","50% HPD"), text.col="gray30", pch=15, pt.cex=1.5, col=colours, box.lty=0, cex=0.6, y.intersp=1.2)
box(lwd=LWD, col="gray30")
	text = "Furthest extent of epidemic wavefront (spatial distance from epidemic origin)"
xLab = "years"; yLab="wavefront distance (km)"
slicedTimes = read.table("WNV_median_spatial_wavefront_distance.txt", header=T)[,"time"]
plot(slicedTimes, waveFrontDistances1MedianValue, type="l", axes=F, ann=F, ylim=yLim1, xlim=xLim)
xx_l = c(slicedTimes,rev(slicedTimes)); yy_l = c(lower_l_1,rev(upper_l_1))
getOption("scipen"); opt = options("scipen"=20)
polygon(xx_l, yy_l, col=rgb(187/255,187/255,187/255,0.5), border=0)
lines(slicedTimes, waveFrontDistances1MedianValue, lwd=1)
axis(side=1, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.020, col.axis="gray30", mgp=c(0,0.2,0))
axis(side=2, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.015, col.axis="gray30")
title(xlab=xLab, cex.lab=0.7, mgp=c(1.4,0,0), col.lab="gray30")
title(ylab=yLab, cex.lab=0.7, mgp=c(1.5,0,0), col.lab="gray30")
title(main=text, cex.main=0.55, col.main="gray30", line=LINE)
box(lwd=LWD, col="gray30")
	text = "Evolution of branch dispersal velocity"
xLab = "years"; yLab="dispersal velocity"
slicedTimes = read.table("WNV_mean_weighted_branch_dispersal_velocity.txt", header=T)[,"time"]
plot(slicedTimes, dispersalVelocitiesMedianValue, type="l", axes=F, ann=F, ylim=yLim, xlim=xLim)
xx_l = c(slicedTimes,rev(slicedTimes)); yy_l = c(lower_l,rev(upper_l))
getOption("scipen"); opt = options("scipen"=20)
polygon(xx_l, yy_l, col=rgb(187/255,187/255,187/255,0.5), border=0)
lines(slicedTimes, dispersalVelocitiesMedianValue, lwd=1)
axis(side=1, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.020, col.axis="gray30", mgp=c(0,0.2,0))
axis(side=2, lwd.tick=LWD, cex.axis=0.6, lwd=0, tck=-0.015, col.axis="gray30")
title(xlab=xLab, cex.lab=0.7, mgp=c(1.4,0,0), col.lab="gray30")
title(ylab=yLab, cex.lab=0.7, mgp=c(1.5,0,0), col.lab="gray30")
title(main=text, cex.main=0.6, col.main="gray30", line=LINE)
box(lwd=LWD, col="gray30")
dev.off()
